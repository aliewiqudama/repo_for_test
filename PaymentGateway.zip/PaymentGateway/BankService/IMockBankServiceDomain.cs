﻿using PaymentGateway.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace PaymentGateway.Domains
{
    public interface IMockBankServiceDomain
    {
        /// <summary>
        /// Retrieves a transaction from the database by its identifier.
        /// </summary>
        /// <param name="id"></param>
        /// <returns>The transaction</returns>
        Task<Transaction> GetTransactionById(Guid id);

        /// <summary>
        /// Commits the transaction and stores it in the database.
        /// </summary>
        /// <param name="transaction"></param>
        /// <returns>The result of the transaction</returns>
        Task<Transaction> Pay(Transaction transaction);
    }
}
