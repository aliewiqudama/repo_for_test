﻿using System;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using PaymentGateway.DataAccess;
using PaymentGateway.Models;

namespace PaymentGateway.Domains
{
    public class MockBankServiceDomain : IMockBankServiceDomain
    {
        /// <inheritdoc/>
        public async Task<Transaction> GetTransactionById(Guid id)
        {
            Transaction transaction = null;
            using (PaymentGatewayDbContext context = new PaymentGatewayDbContext())
            {
                try
                {
                    transaction = await context.Transactions.FirstOrDefaultAsync(t => t.TransactionId == id);
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);
                }
            }
            return transaction;
        }

        /// <inheritdoc/>
        public async Task<Transaction> Pay(Transaction transaction)
        {
            using (PaymentGatewayDbContext context = new PaymentGatewayDbContext())
            {
                try
                {
                    transaction.CardNumber = this.MaskBankCard(transaction.CardNumber);
                    transaction.TransactionStatus = this.IsTransactionValid(transaction) ? TransactionStatus.Success : TransactionStatus.Error;
                    context.Transactions.Add(transaction);
                    await context.SaveChangesAsync();
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);
                }
            }
            return transaction;
        }

        private bool IsTransactionValid(Transaction transaction)
        {
            if (transaction.CardNumber.Length != 16) { return false; }
            if (transaction.CardVerificationValue.ToString().Length != 3) { return false; }
            if (transaction.ExpiryDate <= DateTime.Now) { return false; }
            if (transaction.Amount < 0) { return false; }

            return true;
        }

        private string MaskBankCard(string cardNumber)
        {
            return cardNumber.Substring(cardNumber.Length - 4).PadLeft(cardNumber.Length, '*'); ;
        }
    }    
}
