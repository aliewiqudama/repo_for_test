This application was written using the .NET core framework and leverages EntityFramework Core for its data store. 

To test application:
1 - please run the migration script in order to deploy the database to your local msql server
2 - Use Postman or any other api testing platform of your choice
3 - Endpoints:
	GET: url/api/Payment/{id}
	queries the existing transcations table
	
	POST: url/api/Payment/
	request body example: 
		{
			"cardNumber": "4111111111111111",
			"ExpiryDate": "2020-09-08T19:01:55.714942+03:00",
			"CardVerificationValue": 333,
			"Amount": 10,
			"Currency": "GBP"
		}


p.s. I apologise for the quality of the work as this was written in a short few hours as I was unaware the company was still 
	hiring and wanted to get the test done by friday 3rd of march. 
	In theory I would have added some rudimentary form of abac for authorisation and a build script possibly. 