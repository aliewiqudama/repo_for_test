﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace PaymentGateway.DataAccess.Migrations
{
    public partial class InitialCreate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Transactions",
                columns: table => new
                {
                    TransactionId = table.Column<Guid>(nullable: false),
                    TransactionStatus = table.Column<int>(nullable: false),
                    CardNumber = table.Column<long>(nullable: false),
                    ExpiryDate = table.Column<DateTime>(nullable: false),
                    CardVerificationValue = table.Column<int>(nullable: false),
                    Amount = table.Column<int>(nullable: false),
                    Currency = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Transactions", x => x.TransactionId);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Transactions");
        }
    }
}
