﻿using Microsoft.EntityFrameworkCore;
using PaymentGateway.Models;
using System;

namespace PaymentGateway.DataAccess
{
    public class PaymentGatewayDbContext : DbContext
    {
        public DbSet<Transaction> Transactions { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Data Source=.;Initial Catalog=Bank");
        }
    }
}
