﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace PaymentGateway.Models
{
    public class Transaction
    {
        /// <summary>
        /// Gets or sets the transaction identifier.
        /// </summary>
        /// <value>
        /// The transaction identifier.
        /// </value>
        [Key]
        public Guid TransactionId { get; set; }

        /// <summary>
        /// Gets or sets the transaction status.
        /// </summary>
        /// <value>
        /// The transaction status.
        /// </value>
        public TransactionStatus TransactionStatus { get; set; }

        /// <summary>
        /// Gets or sets the card number.
        /// </summary>
        /// <value>
        /// The card number.
        /// </value>
        public string CardNumber { get; set; }

        /// <summary>
        /// Gets or sets the card expiration date.
        /// </summary>
        /// <value>
        /// The card expiration date.
        /// </value>
        public DateTime ExpiryDate { get; set; }

        /// <summary>
        /// Gets or sets the card verification value.
        /// </summary>
        /// <value>
        /// The verifcation value.
        /// </value>
        public int CardVerificationValue { get; set; }

        /// <summary>
        /// Gets or sets the transaction amount.
        /// </summary>
        /// <value>
        /// The transaction value.
        /// </value>
        public int Amount { get; set; }

        /// <summary>
        /// Gets or sets the currency of the transaction.
        /// </summary>
        /// <value>
        /// The currency of the transaction.
        /// </value>
        public string Currency { get; set; }
    }
}