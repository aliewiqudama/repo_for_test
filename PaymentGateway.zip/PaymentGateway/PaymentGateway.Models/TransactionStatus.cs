﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PaymentGateway.Models
{
   public enum TransactionStatus
    {
        /// <summary>
        /// The transaction was successful
        /// </summary>
        Success = 1,

        /// <summary>
        /// The transaction was successful
        /// </summary>
        Error = 2
    }
}
