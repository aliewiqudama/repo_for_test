﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using PaymentGateway.Models;
using PaymentGateway.Domains;
using PaymentGateway.DataAccess;
using System.Net.Http;

namespace PaymentGateway.Host.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PaymentController : ControllerBase
    {
        private readonly IMockBankServiceDomain mockBankServiceDomain;

        public PaymentController(IMockBankServiceDomain mockBankServiceDomain)
        {
            this.mockBankServiceDomain = mockBankServiceDomain;
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public async Task<IActionResult> Get(Guid id)
        {
            if (id == null)
            {
                return BadRequest("Failed to retrieve transaction");
            }

            var result = await mockBankServiceDomain.GetTransactionById(id);

            return new OkObjectResult(result);
            
        }

        // POST api/values
        [HttpPost]
        public async Task<IActionResult> Pay([FromBody] Transaction transaction)
        {
            if (transaction == null)
            {
                return BadRequest("Invalid parameters in body of Post");
            }
           
            var result = await mockBankServiceDomain.Pay(transaction);

            if (result.TransactionStatus == TransactionStatus.Success)
            {
                return new OkObjectResult(result);
            }
            else
            {
                return BadRequest("The transaction failed");
            }
        }
    }
}